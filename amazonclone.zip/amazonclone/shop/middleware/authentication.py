from django.shortcuts import render


def authentication_middleware(get_response):

    def middleware(request):
        customer_id = request.session.get('customer_id')
        if not customer_id:
            error_message = "You are not logged in !!!"
            return render(request, "failure.html", {"error": error_message})

        response = get_response(request)

        return response

    return middleware
